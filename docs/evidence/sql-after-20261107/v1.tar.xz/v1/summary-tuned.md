# td-sqlperf: tuned on TicketDeskL

Started 2026-11-08T01:10:27.2246994+00:00, finished 2026-11-08T01:11:16.3406157+00:00.  
Cold: CHECKPOINT + DBCC DROPCLEANBUFFERS before every run (buffer pool empty; plan cache kept). Warm: one discarded warm-up run, then the measured runs back to back. median and nearest-rank p95 over the measured runs (p95 = maximum when n < 20).  
Server = SET STATISTICS TIME (outermost execution time, summed over the call's commands); client = wall clock around execute + read all rows.

```
date: 2026-11-08T01:10:27Z
host: lab-host, 32 cores, load average 9.01 7.00 13.54
sql: 16.0.4262.2 Developer Edition (64-bit), MAXDOP(db)=8
database: TicketDeskL; git: e509ff9 (uncommitted changes)
```

| Scenario | Mode | n | Server elapsed median / p95 ms | CPU median / p95 ms | Logical reads (median) | Physical + read-ahead (median) | Client median / p95 ms | Compile CPU ms |
|---|---|---|---|---|---|---|---|---|
| list-default | cold | 5 | 59 / 62 | 43 / 49 | 2,012 | 1,949 | 60.24 / 63.29 | 0 |
| list-default | warm | 20 | 37 / 62 | 37 / 61 | 2,012 | 0 | 38.23 / 63.26 | 0 |
| list-open-p1 | cold | 5 | 76 / 80 | 64 / 66 | 3,395 | 3,316 | 77.08 / 81.29 | 0 |
| list-open-p1 | warm | 20 | 37 / 65 | 37 / 65 | 3,395 | 0 | 37.98 / 66.37 | 0 |
| list-open-p500 | cold | 5 | 66 / 67 | 47 / 50 | 3,482 | 7,154 | 66.57 / 68.13 | 0 |
| list-open-p500 | warm | 20 | 38 / 38 | 38 / 39 | 3,482 | 0 | 38.63 / 39.43 | 0 |
| list-unassigned | cold | 5 | 20 / 20 | 14 / 15 | 2,112 | 3,710 | 20.64 / 21.21 | 0 |
| list-unassigned | warm | 20 | 5 / 5 | 5 / 5 | 1,180 | 0 | 5.79 / 6.1 | 0 |
| list-assignedToMe | cold | 5 | 7 / 9 | 3 / 3 | 273 | 68 | 7.76 / 10.37 | 0 |
| list-assignedToMe | warm | 20 | 0 / 1 | 0 / 1 | 273 | 0 | 0.92 / 1.25 | 0 |
| list-mytickets-heavy | cold | 5 | 14 / 16 | 8 / 9 | 769 | 613 | 14.96 / 16.81 | 0 |
| list-mytickets-heavy | warm | 20 | 2 / 2 | 2 / 2 | 769 | 0 | 2.53 / 3.17 | 0 |
| list-mytickets-light | cold | 5 | 3 / 4 | 2 / 2 | 107 | 23 | 4.13 / 5.26 | 0 |
| list-mytickets-light | warm | 20 | 0 / 0 | 0 / 1 | 107 | 0 | 0.75 / 0.85 | 0 |
| list-history | cold | 5 | 56 / 72 | 45 / 59 | 3,382 | 3,310 | 57.01 / 74 | 0 |
| list-history | warm | 20 | 50.5 / 69 | 50 / 69 | 3,382 | 0 | 51.59 / 70.38 | 0 |
| list-project-big | cold | 5 | 30 / 60 | 23 / 28 | 616 | 469 | 31.59 / 62.61 | 0 |
| list-project-big | warm | 20 | 17 / 20 | 17 / 19 | 616 | 0 | 19.16 / 21.51 | 0 |
| list-project-small | cold | 5 | 23 / 28 | 11 / 13 | 265 | 263 | 25.81 / 29.3 | 0 |
| list-project-small | warm | 20 | 2 / 4 | 2 / 4 | 265 | 0 | 2.7 / 5.54 | 0 |
| list-status-sort-title | cold | 5 | 461 / 919 | 1,672 / 2,007 | 140,542 | 138,944 | 468 / 922 | 0 |
| list-status-sort-title | warm | 20 | 184 / 326 | 880 / 1,080 | 140,542 | 0 | 187 / 327 | 0 |
| list-tag | cold | 5 | 201 / 235 | 157 / 162 | 3,114 | 2,756 | 205 / 238 | 0 |
| list-tag | warm | 20 | 102 / 142 | 102 / 139 | 3,114 | 0 | 103 / 143 | 0 |
| detail | cold | 5 | 3 / 6 | 4 / 6 | 59 | 53 | 10.61 / 14.73 | 0 |
| detail | warm | 20 | 0 / 0 | 0 / 1 | 59 | 0 | 1.39 / 7.72 | 0 |
| report-open-aging | cold | 5 | 206 / 250 | 189 / 239 | 3,704 | 3,865 | 208 / 251 | 12 |
| report-open-aging | warm | 20 | 180 / 227 | 180 / 226 | 3,704 | 0 | 183 / 229 | 5 |
| report-workload | cold | 5 | 344 / 357 | 435 / 477 | 19,189 | 10,444 | 346 / 361 | 39 |
| report-workload | warm | 20 | 164 / 248 | 400 / 454 | 19,095 | 0 | 167 / 251 | 39.5 |
| report-time-to-close | cold | 5 | 460 / 729 | 891 / 958 | 2,641 | 1,977 | 463 / 731 | 5 |
| report-time-to-close | warm | 20 | 456 / 738 | 870 / 1,005 | 2,641 | 0 | 458 / 743 | 4 |

Scenarios:

- `list-default`: GET /api/tickets?(no list; default sort -lastUpdateDate) (1 command(s); plans: `plans/tuned.list-default.cmd1.stmt1.sqlplan`, `plans/tuned.list-default.cmd1.stmt2.sqlplan`, `plans/tuned.list-default.cmd1.stmt3.sqlplan`, `plans/tuned.list-default.cmd1.stmt4.sqlplan`, `plans/tuned.list-default.cmd1.stmt5.sqlplan`, `plans/tuned.list-default.cmd1.stmt6.sqlplan`, `plans/tuned.list-default.cmd1.stmt7.sqlplan`, `plans/tuned.list-default.cmd1.stmt8.sqlplan`, `plans/tuned.list-default.cmd1.stmt9.sqlplan`)
- `list-open-p1`: GET /api/tickets?list=opentickets (sort status,targetDate,dueDate,-lastUpdateDate) (1 command(s); plans: `plans/tuned.list-open-p1.cmd1.stmt1.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt2.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt3.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt4.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt5.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt6.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt7.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt8.sqlplan`, `plans/tuned.list-open-p1.cmd1.stmt9.sqlplan`)
- `list-open-p500`: GET /api/tickets?list=opentickets&page=500 (deep page) (1 command(s); plans: `plans/tuned.list-open-p500.cmd1.stmt1.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt2.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt3.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt4.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt5.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt6.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt7.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt8.sqlplan`, `plans/tuned.list-open-p500.cmd1.stmt9.sqlplan`)
- `list-unassigned`: GET /api/tickets?list=unassigned (help desk) (1 command(s); plans: `plans/tuned.list-unassigned.cmd1.stmt1.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt2.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt3.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt4.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt5.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt6.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt7.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt8.sqlplan`, `plans/tuned.list-unassigned.cmd1.stmt9.sqlplan`)
- `list-assignedToMe`: GET /api/tickets?list=assignedToMe (busiest help desk user) (1 command(s); plans: `plans/tuned.list-assignedToMe.cmd1.stmt1.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt2.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt3.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt4.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt5.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt6.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt7.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt8.sqlplan`, `plans/tuned.list-assignedToMe.cmd1.stmt9.sqlplan`)
- `list-mytickets-heavy`: GET /api/tickets?list=mytickets (owner with the most tickets) (1 command(s); plans: `plans/tuned.list-mytickets-heavy.cmd1.stmt1.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt2.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt3.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt4.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt5.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt6.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt7.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt8.sqlplan`, `plans/tuned.list-mytickets-heavy.cmd1.stmt9.sqlplan`)
- `list-mytickets-light`: GET /api/tickets?list=mytickets (owner with 3-10 open tickets) (1 command(s); plans: `plans/tuned.list-mytickets-light.cmd1.stmt1.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt2.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt3.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt4.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt5.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt6.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt7.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt8.sqlplan`, `plans/tuned.list-mytickets-light.cmd1.stmt9.sqlplan`)
- `list-history`: GET /api/tickets?list=historytickets (closed, sort status,-lastUpdateDate) (1 command(s); plans: `plans/tuned.list-history.cmd1.stmt1.sqlplan`, `plans/tuned.list-history.cmd1.stmt2.sqlplan`, `plans/tuned.list-history.cmd1.stmt3.sqlplan`, `plans/tuned.list-history.cmd1.stmt4.sqlplan`, `plans/tuned.list-history.cmd1.stmt5.sqlplan`, `plans/tuned.list-history.cmd1.stmt6.sqlplan`, `plans/tuned.list-history.cmd1.stmt7.sqlplan`, `plans/tuned.list-history.cmd1.stmt8.sqlplan`, `plans/tuned.list-history.cmd1.stmt9.sqlplan`)
- `list-project-big`: GET /api/tickets?projectId=<biggest project> (default sort) (1 command(s); plans: `plans/tuned.list-project-big.cmd1.stmt1.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt2.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt3.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt4.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt5.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt6.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt7.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt8.sqlplan`, `plans/tuned.list-project-big.cmd1.stmt9.sqlplan`)
- `list-project-small`: GET /api/tickets?projectId=<smallest project> (default sort) (1 command(s); plans: `plans/tuned.list-project-small.cmd1.stmt1.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt2.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt3.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt4.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt5.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt6.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt7.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt8.sqlplan`, `plans/tuned.list-project-small.cmd1.stmt9.sqlplan`)
- `list-status-sort-title`: GET /api/tickets?status=Active&status=MoreInfo&sort=title (1 command(s); plans: `plans/tuned.list-status-sort-title.cmd1.stmt1.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt2.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt3.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt4.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt5.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt6.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt7.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt8.sqlplan`, `plans/tuned.list-status-sort-title.cmd1.stmt9.sqlplan`)
- `list-tag`: GET /api/tickets?tag=<most used tag> (default sort) (1 command(s); plans: `plans/tuned.list-tag.cmd1.stmt1.sqlplan`, `plans/tuned.list-tag.cmd1.stmt2.sqlplan`, `plans/tuned.list-tag.cmd1.stmt3.sqlplan`, `plans/tuned.list-tag.cmd1.stmt4.sqlplan`, `plans/tuned.list-tag.cmd1.stmt5.sqlplan`, `plans/tuned.list-tag.cmd1.stmt6.sqlplan`, `plans/tuned.list-tag.cmd1.stmt7.sqlplan`, `plans/tuned.list-tag.cmd1.stmt8.sqlplan`, `plans/tuned.list-tag.cmd1.stmt9.sqlplan`)
- `detail`: GET /api/tickets/{id} (ticket with the most events) (5 command(s); plans: `plans/tuned.detail.cmd1.stmt1.sqlplan`, `plans/tuned.detail.cmd2.stmt1.sqlplan`, `plans/tuned.detail.cmd3.stmt1.sqlplan`, `plans/tuned.detail.cmd4.stmt1.sqlplan`, `plans/tuned.detail.cmd5.stmt1.sqlplan`)
- `report-open-aging`: GET /api/reports/open-tickets (usp_Report_OpenTicketsAging) (1 command(s); plans: `plans/tuned.report-open-aging.cmd1.stmt1.sqlplan`)
- `report-workload`: GET /api/reports/assignee-workload?top=50 (usp_Report_AssigneeWorkload, Tickets.AssignedDate) (1 command(s); plans: `plans/tuned.report-workload.cmd1.stmt1.sqlplan`, `plans/tuned.report-workload.cmd1.stmt2.sqlplan`)
- `report-time-to-close`: GET /api/reports/time-to-close (last 90 days; usp_Report_TimeToClose) (1 command(s); plans: `plans/tuned.report-time-to-close.cmd1.stmt1.sqlplan`, `plans/tuned.report-time-to-close.cmd1.stmt2.sqlplan`)
