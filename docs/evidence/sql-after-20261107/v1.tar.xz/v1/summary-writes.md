# td-sqlperf: writes on TicketDeskL

Started 2026-11-08T01:11:16.8014717+00:00, finished 2026-11-08T01:11:18.4600904+00:00.  
Cold: CHECKPOINT + DBCC DROPCLEANBUFFERS before every run (buffer pool empty; plan cache kept). Warm: one discarded warm-up run, then the measured runs back to back. median and nearest-rank p95 over the measured runs (p95 = maximum when n < 20).  
Server = SET STATISTICS TIME (outermost execution time, summed over the call's commands); client = wall clock around execute + read all rows.

```
date: 2026-11-08T01:11:16Z
host: lab-host, 32 cores, load average 20.53 10.25 14.33
sql: 16.0.4262.2 Developer Edition (64-bit), MAXDOP(db)=8
database: TicketDeskL; git: e509ff9 (uncommitted changes)
```

| Scenario | Mode | n | Server elapsed median / p95 ms | CPU median / p95 ms | Logical reads (median) | Physical + read-ahead (median) | Client median / p95 ms | Compile CPU ms |
|---|---|---|---|---|---|---|---|---|
| write-reassign | cold | 5 | 2 / 2 | 1 / 2 | 3 | 3 | 5.1 / 9.84 | 1 |
| write-reassign | warm | 20 | 0 / 0 | 0 / 0 | 3 | 0 | 0.57 / 2.83 | 0 |
| write-insert | cold | 5 | 7 / 10 | 4 / 5 | 36 | 25 | 10.44 / 13.63 | 3 |
| write-insert | warm | 20 | 0 / 1 | 0 / 1 | 36 | 0 | 0.95 / 5.6 | 0 |

Scenarios:

- `write-reassign`: EF6-shaped single-ticket reassignment UPDATE, rolled back (1 command(s); plans: `plans/writes.write-reassign.cmd1.stmt1.sqlplan`, `plans/writes.write-reassign.cmd1.stmt2.sqlplan`, `plans/writes.write-reassign.cmd1.stmt3.sqlplan`)
- `write-insert`: EF6-shaped ticket INSERT, rolled back (1 command(s); plans: `plans/writes.write-insert.cmd1.stmt1.sqlplan`, `plans/writes.write-insert.cmd1.stmt2.sqlplan`, `plans/writes.write-insert.cmd1.stmt3.sqlplan`, `plans/writes.write-insert.cmd1.stmt4.sqlplan`, `plans/writes.write-insert.cmd1.stmt5.sqlplan`)
